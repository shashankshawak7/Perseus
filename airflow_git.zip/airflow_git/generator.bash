START=$1
END=$2
for i in $(seq $START $END);
do 
	cp dag_template.py dag_template_$i.py
	new_dag_id=dag_template_$i
	sed -i "s/dag_template\_/$new_dag_id/" $new_dag_id.py
	python $new_dag_id.py
	echo "airflow dags unpause $new_dag_id" >> $3_unpause.sh
done
